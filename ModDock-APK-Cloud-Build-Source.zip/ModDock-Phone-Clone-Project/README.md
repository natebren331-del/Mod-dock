# Mod Dock Phone Clone — source project

**Status: proof-of-concept source code, NOT a tested installable APK.**

This is an entirely phone-based Android APK cloning workflow for **single-APK local WebView applications**. It contains no JavaScript Lab and requires no PC to *operate* once compiled and installed.

## Workflow

1. Select an installed application from Android's visible launcher apps.
2. Select a `.js` or `.mjs` file from the phone's document picker.
3. Select **Build separate modded APK**.
4. The app reads the original installed APK, changes the Android manifest package to `<original>.moddock`, inserts a script into a bundled WebView `index.html`, regenerates the APK's ZIP and signs the copy with APK Signature Scheme v2 using a private signing key generated on the device.
5. The signed copy is saved in **Downloads**. Tap **Install modded APK**, approve unknown app installs if necessary, then **Launch installed modded app** (or launch it from the home screen).

The original APK and original application's data are not modified.

## Build

Open this Gradle project with Android Studio (Android SDK 35 / JDK 17), then build an APK via **Build > Build APK(s)**. Source files use Android's standard SDK APIs and no third-party runtime dependencies. A build environment with Android SDK and Android Gradle Plugin is required. The build environment available for producing this project did not have an Android SDK or APK build tools, so **the project has not been compiled or run on a phone**.

## Compatibility / known limitations

- **No universal JavaScript injection.** This tool only modifies *WebView applications with bundled `assets/.../index.html`*; it explicitly refuses native-library APKs, split APKs, apps with providers/shared UIDs, and APKs without a local HTML entry point.
- JS executes only if the target WebView actually loads that patched HTML page. A Content Security Policy, app-integrity check, resource/package assumptions, or web-navigation model may prevent it.
- An ordinary `.js` script is loaded as a classic script and an `.mjs` or ES-module file uses `type="module"`. These scripts run within the modified copied page, **not inside Android native code**.
- A package ID change may break app-specific package checks, licensing, OAuth callbacks, native providers, or other assumptions. The original package is untouched.
- APKs using Android App Bundles/splits, asset delivery, native libraries, or complex resource/manifest edge cases cannot be safely cloned with this implementation.
- Only Android API 29+ is supported; phone needs the **Install unknown apps** permission to launch the package installer.
- Files above 80 MiB are rejected to avoid phone memory exhaustion. JavaScript mods are limited to 1 MiB.
- The signing key is created in **Android Keystore**. A reinstall after data deletion may produce a new signing key and require uninstalling previously signed clones before updating them. `AndroidKeyStore` lifecycle matters.
- This is a source implementation, not a finished app tested on Android hardware. Test it on a sacrificial WebView sample app before using real applications; it is not suitable for sensitive apps.

## Scope

The code intentionally does **not** attempt stealthy code injection into other running apps, bypass Android security boundaries, or pretend a random `.js` file can modify a Unity or native game. It is a best-effort, explicitly limited WebView APK packager.

## Optional cloud build (no Android Studio required on the phone)

The project includes `.github/workflows/build-apk.yml`. If you upload its files to a GitHub repository, the **Build phone-only Mod Dock APK** GitHub Actions workflow can be run from the Actions tab. On success, download the **ModDock-Phone-Clone-Debug-APK** artifact, extract its `app-debug.apk`, and install it on Android. This uses GitHub's build environment, not a PC connected to the phone. **The cloud workflow itself has not been run or verified from this conversation.**
