package com.moddock.clone;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.util.Arrays;
import java.util.Date;
import javax.security.auth.x500.X500Principal;

/** APK Signature Scheme v2 signer. Key generated on the phone stays in Android Keystore. */
final class ApkV2Signer {
    private static final String ALIAS="ModDockPhoneCloneV2";
    private static final byte[] MAGIC="APK Sig Block 42".getBytes(StandardCharsets.US_ASCII);
    private static final int ALGORITHM=0x0103; // RSA PKCS#1 v1.5 / SHA-256
    private static final int SIGNING_BLOCK_ID=0x7109871a;
    private static final int CHUNK=1024*1024;
    private ApkV2Signer() {}

    static void sign(Context context, File unsigned, File result) throws Exception {
        if(unsigned.length()>100L*1024*1024)throw new IOException("APK too large for in-memory signer");
        byte[] zip=Files.readAllBytes(unsigned.toPath());
        int eocd=findEocd(zip);
        int cd=u32(zip,eocd+16);
        if(cd<=0 || cd>=eocd)throw new IOException("ZIP central directory is invalid");
        KeyStore keystore=KeyStore.getInstance("AndroidKeyStore");keystore.load(null);
        if(!keystore.containsAlias(ALIAS)){
            KeyPairGenerator generator=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore");
            Date start=new Date(System.currentTimeMillis()-86400_000L);
            Date end=new Date(System.currentTimeMillis()+3650L*86400_000L);
            KeyGenParameterSpec params=new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
               .setKeySize(3072)
               .setDigests(KeyProperties.DIGEST_SHA256)
               .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
               .setCertificateSubject(new X500Principal("CN=Mod Dock local app clones"))
               .setCertificateSerialNumber(BigInteger.valueOf(20261113L))
               .setCertificateNotBefore(start).setCertificateNotAfter(end)
               .build();
            generator.initialize(params);generator.generateKeyPair();
            keystore.load(null);
        }
        KeyStore.Entry e=keystore.getEntry(ALIAS,null);
        if(!(e instanceof KeyStore.PrivateKeyEntry))throw new IOException("Signing key unavailable");
        KeyStore.PrivateKeyEntry entry=(KeyStore.PrivateKeyEntry)e;
        signWithKey(entry.getPrivateKey(),entry.getCertificate(),zip,cd,eocd,result);
    }

    /** Separately testable v2 signing core. */
    static void signWithKey(PrivateKey key, Certificate cert, byte[] zip, int cd, int eocd, File result) throws Exception {
        byte[] contentDigest=contentDigest(zip,cd,eocd);
        byte[] digestRecord=concat(le32(ALGORITHM),lp(contentDigest));
        byte[] signedData=concat(lp(lp(digestRecord)),lp(lp(cert.getEncoded())),lp(new byte[0]));
        Signature signer=Signature.getInstance("SHA256withRSA");
        signer.initSign(key);signer.update(signedData);
        byte[] signed=signer.sign();
        Signature verifier=Signature.getInstance("SHA256withRSA");
        verifier.initVerify(cert);verifier.update(signedData);
        if(!verifier.verify(signed))throw new IOException("APK signature verification failed");
        byte[] signerRecord=concat(lp(signedData),lp(lp(concat(le32(ALGORITHM),lp(signed)))),lp(cert.getPublicKey().getEncoded()));
        byte[] v2Data=lp(lp(signerRecord));
        byte[] pair=concat(le64(v2Data.length+4),le32(SIGNING_BLOCK_ID),v2Data);
        byte[] block=concat(le64(pair.length+24),pair,le64(pair.length+24),MAGIC);
        byte[] tail=Arrays.copyOfRange(zip,eocd,zip.length);
        put32(tail,16,cd+block.length);
        try(FileOutputStream out=new FileOutputStream(result)) {
            out.write(zip,0,cd);out.write(block);
            out.write(zip,cd,eocd-cd);out.write(tail);
        }
        // Validate block placement and the actual signed contents after serialization.
        byte[] check=Files.readAllBytes(result.toPath());
        int realEocd=findEocd(check);
        int newCd=u32(check,realEocd+16);
        if(newCd!=cd+block.length || !Arrays.equals(MAGIC,Arrays.copyOfRange(check,newCd-16,newCd)))
            throw new IOException("Generated APK has an invalid signing-block layout");
        if(!Arrays.equals(contentDigest,contentDigestWithSigningBlock(check,cd,newCd,realEocd)))
            throw new IOException("Signed APK contents were corrupted");
    }

    private static byte[] contentDigest(byte[] zip,int cd,int eocd)throws Exception{
        byte[] end=Arrays.copyOfRange(zip,eocd,zip.length);
        return digestOfSections(zip,0,cd,cd,eocd,end);
    }
    private static byte[] contentDigestWithSigningBlock(byte[] apk,int originalCd,int newCd,int eocd)throws Exception{
        byte[] end=Arrays.copyOfRange(apk,eocd,apk.length);
        put32(end,16,originalCd);
        return digestOfSections(apk,0,originalCd,newCd,eocd,end);
    }
    private static byte[] digestOfSections(byte[] all,int prefixStart,int prefixEnd,int cdStart,int cdEnd,byte[] eocd)throws Exception{
        ByteArrayOutputStream pieces=new ByteArrayOutputStream();
        int count=0;
        count+=digestChunks(all,prefixStart,prefixEnd,pieces);
        count+=digestChunks(all,cdStart,cdEnd,pieces);
        count+=digestChunks(eocd,0,eocd.length,pieces);
        MessageDigest sha=MessageDigest.getInstance("SHA-256");
        sha.update((byte)0x5a);sha.update(le32(count));sha.update(pieces.toByteArray());
        return sha.digest();
    }
    private static int digestChunks(byte[] src,int from,int to,ByteArrayOutputStream output)throws Exception{
        int count=0;
        for(int off=from;off<to;off+=CHUNK){
            int n=Math.min(CHUNK,to-off);
            MessageDigest sha=MessageDigest.getInstance("SHA-256");
            sha.update((byte)0xa5);sha.update(le32(n));sha.update(src,off,n);
            output.write(sha.digest());count++;
        }
        return count;
    }
    private static int findEocd(byte[] a)throws IOException{
        for(int p=a.length-22;p>=Math.max(0,a.length-22-65535);p--){
            if(a[p]==0x50 && a[p+1]==0x4b && a[p+2]==0x05 && a[p+3]==0x06 && p+22+u16(a,p+20)==a.length)
                return p;
        }
        throw new IOException("Unsupported ZIP: couldn't find end-of-central-directory record");
    }
    private static int u16(byte[] a,int p){return (a[p]&255)|((a[p+1]&255)<<8);}
    private static int u32(byte[] a,int p){return (a[p]&255)|((a[p+1]&255)<<8)|((a[p+2]&255)<<16)|((a[p+3]&255)<<24);}
    private static void put32(byte[] a,int p,int n){a[p]=(byte)n;a[p+1]=(byte)(n>>8);a[p+2]=(byte)(n>>16);a[p+3]=(byte)(n>>24);}
    private static byte[] le32(int n){return new byte[]{(byte)n,(byte)(n>>>8),(byte)(n>>>16),(byte)(n>>>24)};}
    private static byte[] le64(long n){return new byte[]{(byte)n,(byte)(n>>>8),(byte)(n>>>16),(byte)(n>>>24),(byte)(n>>>32),(byte)(n>>>40),(byte)(n>>>48),(byte)(n>>>56)};}
    private static byte[] lp(byte[] a){return concat(le32(a.length),a);}
    private static byte[] concat(byte[]...arrays){
        int n=0;for(byte[]a:arrays)n+=a.length;
        byte[]out=new byte[n];int p=0;
        for(byte[]a:arrays){System.arraycopy(a,0,out,p,a.length);p+=a.length;}
        return out;
    }
}
