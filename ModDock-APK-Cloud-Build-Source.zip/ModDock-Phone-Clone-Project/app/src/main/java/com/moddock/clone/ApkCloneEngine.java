package com.moddock.clone;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import java.util.zip.CRC32;
import java.io.InputStream;
import java.util.regex.Pattern;

/** Local WebView-app clone builder; intentionally rejects non-WebView / split APKs. */
final class ApkCloneEngine {
    private static final int MAX_APK=80*1024*1024;
    private static final Pattern CLONE_ID=Pattern.compile("[A-Za-z_][A-Za-z_0-9]*(\\.[A-Za-z_][A-Za-z_0-9]*)+");
    private ApkCloneEngine() {}

    static String createClone(File source, File output, String clonePkg, byte[] mod, String modFileName) throws Exception {
        if (!CLONE_ID.matcher(clonePkg).matches()) throw new IllegalArgumentException("Invalid clone package ID");
        if (source.length()>MAX_APK) throw new IllegalArgumentException("APK is too large for the phone-only signer (80 MiB maximum)");
        try (ZipFile apk = new ZipFile(source)) {
            ZipEntry manifestEntry=apk.getEntry("AndroidManifest.xml");
            if (manifestEntry==null) throw new IllegalArgumentException("This is not an Android APK");
            byte[] axml=readEntry(apk,manifestEntry);
            BinaryManifest manifest=new BinaryManifest(axml);
            String sourcePkg=manifest.packageName();
            if (sourcePkg.equals(clonePkg)) throw new IllegalArgumentException("Clone must have a different app ID");
            if (manifest.hasTag("provider") || manifest.hasAttribute("sharedUserId"))
                throw new IllegalArgumentException("This APK declares providers/shared UID. Safe independent cloning isn't supported for it.");
            if (manifest.hasTag("uses-split")) throw new IllegalArgumentException("This app needs additional split APKs.");
            byte[] clonedManifest=manifest.changePackage(sourcePkg,clonePkg);
            List<String> htmlCandidates=new ArrayList<>();
            for (ZipEntry e: Collections.list(apk.entries())) {
                String name=e.getName();
                if (name.startsWith("lib/") && name.endsWith(".so"))
                    throw new IllegalArgumentException("Native-library APKs aren't supported; JavaScript can't hook native code automatically.");
                if (name.startsWith("assets/") && name.toLowerCase(Locale.ROOT).endsWith("/index.html")) htmlCandidates.add(name);
                if (name.equals("assets/index.html")) htmlCandidates.add(name);
            }
            if (htmlCandidates.isEmpty()) throw new IllegalArgumentException("No bundled WebView index.html found. This isn't a supported local-HTML WebView app.");
            Collections.sort(htmlCandidates, (a,b) -> Integer.compare(rank(a),rank(b)));
            String htmlPath=htmlCandidates.get(0);
            String parent=htmlPath.substring(0,htmlPath.lastIndexOf('/')+1);
            String scriptPath=parent+"moddock-injected"+(isModule(modFileName,mod)?".mjs":".js");
            if (apk.getEntry(scriptPath)!=null) throw new IllegalArgumentException("APK already contains the Mod Dock injection script");
            String jsType=scriptPath.endsWith(".mjs")?" type=\"module\"":" defer";
            String scriptTag="<script"+jsType+" src=\""+scriptPath.substring(parent.length())+"\"></script>";
            byte[] htmlRaw=readEntry(apk,apk.getEntry(htmlPath));
            String html=new String(htmlRaw,StandardCharsets.UTF_8);
            if (html.toLowerCase(Locale.ROOT).contains("</head>"))
                html=html.replaceFirst("(?i)</head\\s*>",java.util.regex.Matcher.quoteReplacement(scriptTag+"\n</head>"));
            else if (html.toLowerCase(Locale.ROOT).contains("</body>"))
                html=html.replaceFirst("(?i)</body\\s*>",java.util.regex.Matcher.quoteReplacement(scriptTag+"\n</body>"));
            else throw new IllegalArgumentException("HTML has no closing HEAD/BODY tag");

            Map<String,byte[]> patches=new HashMap<>();
            patches.put("AndroidManifest.xml",clonedManifest);
            patches.put(htmlPath,html.getBytes(StandardCharsets.UTF_8));
            patches.put(scriptPath,mod);
            try (CountingOutputStream counting=new CountingOutputStream(new FileOutputStream(output));
                 ZipOutputStream out=new ZipOutputStream(counting)) {
                for (ZipEntry entry : Collections.list(apk.entries())) {
                    String name=entry.getName();
                    String upper=name.toUpperCase(Locale.ROOT);
                    if (upper.startsWith("META-INF/") && (upper.endsWith(".RSA")||upper.endsWith(".SF")||upper.endsWith(".DSA")||upper.endsWith(".EC")||upper.equals("META-INF/MANIFEST.MF"))) continue;
                    if (name.equals(scriptPath)) continue;
                    byte[] data=patches.containsKey(name)?patches.get(name):readEntry(apk,entry);
                    ZipEntry dest=new ZipEntry(name);
                    dest.setTime(315532800000L); // fixed 1980 timestamp
                    if (entry.getMethod()==ZipEntry.STORED) {
                        dest.setMethod(ZipEntry.STORED);
                        dest.setSize(data.length);
                        CRC32 crc=new CRC32();crc.update(data);dest.setCrc(crc.getValue());
                        // Keep uncompressed files 4-byte aligned for Android's mmap requirements.
                        int nameBytes=name.getBytes(StandardCharsets.UTF_8).length;
                        int extraPad=(4-(int)((counting.count()+30+nameBytes+4)%4))%4;
                        dest.setExtra(alignmentExtra(extraPad));
                    } else dest.setMethod(ZipEntry.DEFLATED);
                    out.putNextEntry(dest);out.write(data);out.closeEntry();
                }
                ZipEntry injected=new ZipEntry(scriptPath);
                injected.setTime(315532800000L);
                out.putNextEntry(injected);out.write(mod);out.closeEntry();
            }
            return htmlPath;
        }
    }

    private static int rank(String path) {
        switch(path) {
            case "assets/www/index.html":return 0;
            case "assets/index.html":return 1;
            case "assets/web/index.html":return 2;
            case "assets/public/index.html":return 3;
            default:return 100;
        }
    }
    private static boolean isModule(String name, byte[] mod) {
        String text=new String(mod,StandardCharsets.UTF_8);
        return name.toLowerCase(Locale.ROOT).endsWith(".mjs") ||
               Pattern.compile("(?m)^\\s*(import\\s+[^(']|export\\s+)").matcher(text).find();
    }
    private static byte[] alignmentExtra(int padding) {
        byte[] e=new byte[4+padding];e[0]=(byte)0xfe;e[1]=(byte)0xca;e[2]=(byte)padding;e[3]=0;return e;
    }
    private static byte[] readEntry(ZipFile z,ZipEntry entry) throws IOException {
        if (entry.getSize()>MAX_APK) throw new IOException("Oversized ZIP member");
        try (InputStream in=z.getInputStream(entry);ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[32768];int n;
            while ((n=in.read(b))!=-1) {if (out.size()+n>MAX_APK) throw new IOException("Oversized ZIP member");out.write(b,0,n);}
            return out.toByteArray();
        }
    }
    private static class CountingOutputStream extends OutputStream {
        private final OutputStream out;
        private long count;
        CountingOutputStream(OutputStream out){this.out=out;}
        long count(){return count;}
        @Override public void write(int b)throws IOException{out.write(b);count++;}
        @Override public void write(byte[] b,int off,int len)throws IOException{out.write(b,off,len);count+=len;}
        @Override public void flush()throws IOException{out.flush();}
        @Override public void close()throws IOException{out.close();}
    }

    /** Android binary XML parser that appends new strings and patches attribute indices. */
    private static class BinaryManifest {
        final byte[] blob;
        final List<String> strings=new ArrayList<>();
        final List<Attr> attrs=new ArrayList<>();
        final Map<Integer,String> tags=new HashMap<>();
        final boolean utf8;
        final int poolEnd,poolFlags,rootHeader,poolHeader;
        final int oldStringCount;
        final List<Integer> elementOffsets=new ArrayList<>();
        private static class Attr {
            String tag,name;int rawIndex,typedIndex,typedValue,typedType,relativeOffset;
        }
        BinaryManifest(byte[] blob)throws IOException{
            this.blob=blob;
            if (blob.length<36 || u16(blob,0)!=3 || u16(blob,2)!=8 || u16(blob,8)!=1)
                throw new IOException("Expected binary AndroidManifest.xml");
            rootHeader=u16(blob,2);poolHeader=u16(blob,10);
            if(poolHeader!=28)throw new IOException("Unexpected manifest string-pool format");
            int poolLen=u32(blob,12),count=u32(blob,16),styles=u32(blob,20);
            poolFlags=u32(blob,24);utf8=(poolFlags&0x100)!=0;
            if(styles!=0 || count<1 || count>300000 || poolLen<28 || poolLen+8>blob.length)
                throw new IOException("Unsupported styled Android string pool");
            oldStringCount=count;poolEnd=8+poolLen;
            int stringData=u32(blob,28);
            for(int i=0;i<count;i++){
                int pos=8+stringData+u32(blob,8+poolHeader+i*4);
                if(pos<0 || pos>=poolEnd)throw new IOException("Corrupt AXML string pointer");
                int[] index={pos};
                if(utf8){readUtf8Length(blob,index);int n=readUtf8Length(blob,index);
                    if(n>poolEnd-index[0])throw new IOException("Truncated AXML string");
                    strings.add(new String(blob,index[0],n,StandardCharsets.UTF_8));
                }else{int n=readUtf16Length(blob,index);if(n*2>poolEnd-index[0])throw new IOException("Truncated AXML string");
                    strings.add(new String(blob,index[0],n*2,StandardCharsets.UTF_16LE));}
            }
            for(int pos=poolEnd;pos+8<=blob.length;){
                int typ=u16(blob,pos),size=u32(blob,pos+4);
                if(size<8 || pos+size>blob.length)throw new IOException("Malformed AXML node");
                if(typ==0x102){
                    int nameIdx=u32(blob,pos+20);
                    String tag=str(nameIdx);
                    int attrStart=u16(blob,pos+24),attrSize=u16(blob,pos+26),attributeCount=u16(blob,pos+28);
                    if(attrSize<20 || pos+16+attrStart+attributeCount*attrSize>pos+size)throw new IOException("Invalid AXML attribute layout");
                    for(int i=0;i<attributeCount;i++){
                        int a=pos+16+attrStart+i*attrSize;
                        Attr attr=new Attr();attr.tag=tag;attr.name=str(u32(blob,a+4));
                        attr.rawIndex=u32(blob,a+8);attr.typedType=blob[a+15]&255;attr.typedValue=u32(blob,a+16);
                        attr.typedIndex=attr.typedType==3?attr.typedValue:-1;
                        attr.relativeOffset=a-poolEnd;
                        attrs.add(attr);
                    }
                }
                pos+=size;
            }
        }
        private String str(int index)throws IOException {
            if(index<0||index>=strings.size())throw new IOException("Invalid AXML string index");return strings.get(index);
        }
        String packageName()throws IOException {
            for(Attr a:attrs)if(a.tag.equals("manifest")&&a.name.equals("package"))return text(a);
            throw new IOException("Manifest package name is missing");
        }
        boolean hasTag(String tag){for(Attr a:attrs)if(a.tag.equals(tag))return true;return false;}
        boolean hasAttribute(String name){for(Attr a:attrs)if(a.name.equals(name))return true;return false;}
        String text(Attr a)throws IOException {
            if(a.rawIndex!=-1)return str(a.rawIndex);
            if(a.typedIndex!=-1)return str(a.typedIndex);
            return null;
        }
        byte[] changePackage(String source,String clone)throws IOException {
            Map<Integer,String> replacements=new LinkedHashMap<>();
            // Copy all of the original string-pool entries untouched: references from
            // other AXML chunks are still valid after additional entries are appended.
            List<String> newStrings=new ArrayList<>(strings);
            for(Attr a:attrs){
                String old=text(a);
                if(old==null)continue;
                String newer=null;
                if(a.tag.equals("manifest")&&a.name.equals("package"))newer=clone;
                else if((a.tag.equals("application") || a.tag.equals("activity") || a.tag.equals("activity-alias") || a.tag.equals("service") || a.tag.equals("receiver") || a.tag.equals("instrumentation")) &&
                       (a.name.equals("name") || a.name.equals("targetActivity") || a.name.equals("backupAgent") || a.name.equals("appComponentFactory") || a.name.equals("manageSpaceActivity"))) {
                    if(old.startsWith("."))newer=source+old;
                    else if(!old.contains("."))newer=source+"."+old;
                }
                if(a.name.equals("permission") || a.name.equals("readPermission") || a.name.equals("writePermission") || a.name.equals("authorities")) {
                    if(old.contains(source))newer=old.replace(source,clone);
                }
                if(newer!=null && !newer.equals(old)) {
                    int index=newStrings.indexOf(newer);
                    if(index<0){index=newStrings.size();newStrings.add(newer);}
                    replacements.put(a.relativeOffset,newer); // per-attribute, not per-shared string
                }
            }
            if(replacements.isEmpty())throw new IOException("No manifest package attribute to change");
            ByteArrayOutputStream text=new ByteArrayOutputStream();
            ByteArrayOutputStream offsets=new ByteArrayOutputStream();
            for(String s:newStrings){write32(offsets,text.size());byte[] raw=s.getBytes(utf8?StandardCharsets.UTF_8:StandardCharsets.UTF_16LE);
                if(utf8){writeUtf8Length(text,s.length());writeUtf8Length(text,raw.length);text.write(raw,0,raw.length);text.write(0);}
                else{writeUtf16Length(text,s.length());text.write(raw,0,raw.length);text.write(0);text.write(0);}
            }
            while(text.size()%4!=0)text.write(0);
            int newPoolSize=28+newStrings.size()*4+text.size();
            ByteArrayOutputStream pool=new ByteArrayOutputStream();
            write16(pool,1);write16(pool,28);write32(pool,newPoolSize);
            write32(pool,newStrings.size());write32(pool,0);write32(pool,poolFlags);
            write32(pool,28+newStrings.size()*4);write32(pool,0);
            pool.write(offsets.toByteArray(),0,offsets.size());pool.write(text.toByteArray(),0,text.size());
            byte[] rest=new byte[blob.length-poolEnd];
            System.arraycopy(blob,poolEnd,rest,0,rest.length);
            for(Attr a:attrs){
                String newer=replacements.get(a.relativeOffset);
                if(newer==null)continue;
                int index=newStrings.indexOf(newer);
                if(a.rawIndex!=-1)put32(rest,a.relativeOffset+8,index);
                if(a.typedType==3)put32(rest,a.relativeOffset+16,index);
            }
            ByteArrayOutputStream output=new ByteArrayOutputStream();
            byte[] hdr=new byte[8];System.arraycopy(blob,0,hdr,0,8);
            put32(hdr,4,8+newPoolSize+rest.length);
            output.write(hdr,0,hdr.length);output.write(pool.toByteArray(),0,pool.size());output.write(rest,0,rest.length);
            return output.toByteArray();
        }
        private static int u16(byte[] a,int pos){return (a[pos]&255)|((a[pos+1]&255)<<8);}
        private static int u32(byte[] a,int pos){return (a[pos]&255)|((a[pos+1]&255)<<8)|((a[pos+2]&255)<<16)|((a[pos+3]&255)<<24);}
        private static void put32(byte[] a,int p,int v){a[p]=(byte)v;a[p+1]=(byte)(v>>>8);a[p+2]=(byte)(v>>>16);a[p+3]=(byte)(v>>>24);}
        private static void write16(ByteArrayOutputStream a,int v){a.write(v&255);a.write(v>>>8&255);}
        private static void write32(ByteArrayOutputStream a,int v){a.write(v&255);a.write(v>>>8&255);a.write(v>>>16&255);a.write(v>>>24&255);}
        private static int readUtf8Length(byte[] bytes,int[] p){int first=bytes[p[0]++]&255;return (first&128)!=0?((first&127)<<8)|(bytes[p[0]++]&255):first;}
        private static int readUtf16Length(byte[] bytes,int[] p){int first=u16(bytes,p[0]);p[0]+=2;
            if((first&0x8000)==0)return first;
            int next=u16(bytes,p[0]);p[0]+=2;return ((first&0x7fff)<<16)|next;}
        private static void writeUtf8Length(ByteArrayOutputStream b,int n)throws IOException{
            if(n<0x80)b.write(n);
            else if(n<=32767){b.write(((n>>8)&127)|128);b.write(n&255);}
            else throw new IOException("AXML string too long");
        }
        private static void writeUtf16Length(ByteArrayOutputStream b,int n)throws IOException{
            if(n<32768)write16(b,n);else{write16(b,(n>>16)|0x8000);write16(b,n);}
        }
    }
}
