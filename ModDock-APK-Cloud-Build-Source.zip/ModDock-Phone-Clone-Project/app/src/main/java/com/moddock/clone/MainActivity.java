package com.moddock.clone;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native UI: select installed app -> select a JavaScript file -> produce a signed clone. */
public final class MainActivity extends Activity {
    private static final int PICK_MOD = 40;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Choice> choices = new ArrayList<>();
    private Choice chosen;
    private Uri scriptUri;
    private String scriptName;
    private Uri lastApk;
    private String lastClonePackage;
    private Button chooseApp, chooseMod, build, install, launch;
    private TextView status;

    private static final class Choice {
        String name, pkg;
        Choice(String name, String pkg) { this.name = name; this.pkg = pkg; }
        @Override public String toString() { return name + " (" + pkg + ")"; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 38, 32, 30);
        scroll.addView(layout);
        TextView title = new TextView(this);
        title.setText("Mod Dock — App Copy + JS Mod");
        title.setTextSize(23);
        layout.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Builds a separate signed copy of compatible WebView apps with your JavaScript embedded. No PC, IPv4, or JavaScript lab. Unsupported apps are reported rather than silently producing broken clones.");
        subtitle.setPadding(0, 12, 0, 20);
        layout.addView(subtitle);
        chooseApp = addButton(layout, "1. Select installed app", v -> selectApp());
        chooseMod = addButton(layout, "2. Import .js / .mjs", v -> selectMod());
        build = addButton(layout, "3. Build separate modded APK", v -> buildCopy());
        install = addButton(layout, "4. Install modded APK", v -> installCopy());
        launch = addButton(layout, "5. Launch installed modded app", v -> launchCopy());
        install.setEnabled(false);
        launch.setEnabled(false);
        status = new TextView(this);
        status.setPadding(0, 22, 0, 0);
        status.setText("Select an installed app and import a JavaScript mod.");
        status.setTextIsSelectable(true);
        layout.addView(status);
        setContentView(scroll);
    }

    private Button addButton(LinearLayout l, String text, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        l.addView(b);
        b.setOnClickListener(action);
        return b;
    }

    private void selectApp() {
        choices.clear();
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
        Set<String> found = new HashSet<>();
        for (ResolveInfo r : infos) {
            if (r.activityInfo == null) continue;
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !found.add(pkg)) continue;
            String label = String.valueOf(r.loadLabel(pm));
            choices.add(new Choice(label, pkg));
        }
        Collections.sort(choices, Comparator.comparing(c -> c.name.toLowerCase()));
        if (choices.isEmpty()) { status.setText("No launchable apps are visible. Check Android's app visibility settings."); return; }
        String[] options = new String[choices.size()];
        for (int i=0;i<choices.size();i++) options[i] = choices.get(i).toString();
        new AlertDialog.Builder(this).setTitle("Choose an installed app")
            .setItems(options, (dialog, which) -> {
                chosen=choices.get(which); lastApk=null; lastClonePackage=null; install.setEnabled(false); launch.setEnabled(false);
                status.setText("Selected app: " + chosen + "\nSelect a .js or .mjs mod.");
            }).setNegativeButton("Cancel", null).show();
    }

    private void selectMod() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("*/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(pick, PICK_MOD);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_MOD || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri=data.getData();
        String name = "selected.js";
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        if (!(name.toLowerCase().endsWith(".js") || name.toLowerCase().endsWith(".mjs"))) {
            status.setText("Select a .js or .mjs file, not " + name); return;
        }
        scriptUri=uri; scriptName=name; lastApk=null; lastClonePackage=null; install.setEnabled(false); launch.setEnabled(false);
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
        status.setText("Loaded mod: " + scriptName + "\nSelected app: " + (chosen == null ? "none" : chosen));
    }

    private void buildCopy() {
        if (chosen == null || scriptUri == null) { status.setText("Select both an installed app and a .js or .mjs file."); return; }
        final Choice choice=chosen;
        final Uri mod=scriptUri;
        final String fileName=scriptName;
        build.setEnabled(false); install.setEnabled(false); launch.setEnabled(false);
        status.setText("Inspecting APK and building clone…");
        executor.execute(() -> {
            File apk = new File(getCacheDir(), "moddock-clone-unsigned.apk");
            File signed = new File(getCacheDir(), "moddock-clone-signed.apk");
            try {
                android.content.pm.ApplicationInfo ai = getPackageManager().getApplicationInfo(choice.pkg, 0);
                if (ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0)
                    throw new IllegalArgumentException("This app uses split APKs; this build supports single-APK WebView apps only.");
                byte[] js = readLimited(mod, 1024*1024);
                if (js.length == 0) throw new IllegalArgumentException("The mod is empty.");
                String clonePkg=choice.pkg + ".moddock";
                String html=ApkCloneEngine.createClone(new File(ai.sourceDir), apk, clonePkg, js, fileName);
                ApkV2Signer.sign(this, apk, signed);
                Uri download = saveToDownloads(signed, choice.name.replaceAll("[^A-Za-z0-9_-]", "_") + "-ModDock.apk");
                lastApk=download;
                lastClonePackage=clonePkg;
                ui.post(() -> { build.setEnabled(true); install.setEnabled(true); launch.setEnabled(true); status.setText("Clone built and signed.\nModified HTML: " + html + "\nInstalled app stays untouched.\nSaved to Downloads. Tap Install modded APK, then Launch installed modded app."); });
            } catch (Exception ex) {
                ui.post(() -> { build.setEnabled(true); status.setText("Cannot build this app: " + ex.getMessage()); });
            } finally { apk.delete(); signed.delete(); }
        });
    }

    private byte[] readLimited(Uri u, int limit) throws Exception {
        try (InputStream in=getContentResolver().openInputStream(u); java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()) {
            if (in == null) throw new IllegalArgumentException("Can't open the JavaScript file.");
            byte[] b=new byte[8192]; int n;
            while ((n=in.read(b))!=-1) { if (out.size()+n>limit) throw new IllegalArgumentException("JavaScript mod must be 1 MiB or smaller."); out.write(b,0,n); }
            return out.toByteArray();
        }
    }

    private Uri saveToDownloads(File source, String displayName) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Downloads.DISPLAY_NAME,displayName);
        cv.put(MediaStore.Downloads.MIME_TYPE,"application/vnd.android.package-archive");
        cv.put(MediaStore.Downloads.IS_PENDING,1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
        if (uri == null) throw new IllegalStateException("Could not create a Downloads entry");
        boolean okay=false;
        try (InputStream in=new FileInputStream(source); OutputStream out=getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalArgumentException("Cannot write the cloned APK to Downloads");
            byte[] buf=new byte[65536]; int n; while ((n=in.read(buf))!=-1) out.write(buf,0,n);
            okay=true;
        } finally {
            if (okay) { cv.clear();cv.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,cv,null,null); }
            else getContentResolver().delete(uri,null,null);
        }
        return uri;
    }

    private void installCopy() {
        if (lastApk == null) return;
        try {
            if (!getPackageManager().canRequestPackageInstalls()) {
                Intent settings = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                       Uri.parse("package:"+getPackageName()));
                startActivity(settings);
                status.setText("Allow this app to install APKs, return here, and tap Install again.");
                return;
            }
            Intent install=new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(lastApk,"application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
        } catch (Exception e) { status.setText("Installer could not open: " + e.getMessage() + "\nOpen the APK from Downloads instead."); }
    }

    private void launchCopy() {
        if (lastClonePackage == null) return;
        try {
            Intent app = getPackageManager().getLaunchIntentForPackage(lastClonePackage);
            if (app == null) {
                // Launcher intents may be hidden by Android's package-visibility rules.
                app = new Intent(Intent.ACTION_MAIN);
                app.addCategory(Intent.CATEGORY_LAUNCHER);
                app.setPackage(lastClonePackage);
            }
            app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(app);
        } catch (Exception ex) {
            status.setText("Can't launch clone yet. Install it first, then launch it from your Android home screen. " + ex.getMessage());
        }
    }

    @Override protected void onDestroy() { executor.shutdown(); super.onDestroy(); }
}
