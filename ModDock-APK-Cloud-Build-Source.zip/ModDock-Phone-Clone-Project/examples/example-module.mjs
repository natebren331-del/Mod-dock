// Example ES module for a compatible WebView app.
console.log('Mod Dock ES module loaded in the copied WebView app');
export const active = true;
