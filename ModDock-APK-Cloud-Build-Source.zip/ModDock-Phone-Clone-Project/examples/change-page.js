// For compatible WebView apps: changes the WebView document only.
(() => {
  console.log('Mod Dock injected this script into the copied app');
  if (document.body) document.body.dataset.modDockActive = 'true';
})();
